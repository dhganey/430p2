Hello CSE 430 graders!

Thank you for taking the time to examine my project.
A summary of the project methodology can be found in the PDF file.
To run my program, simply ensure that the following directory structure is observed:
- main.cpp and main.h source files are in root directory, along with run.sh and Makefile
- input files are in root/input
- output directory (initially empty) at root/output

Executing run.sh will compile my translator program and run it for all inputs.
It will then compile and run all the output files. These will be stored in the outputs
directory so you can execute them again later.

If you have any difficulties, please feel free to contact me.

Thanks!

David Ganey